import AthleticsImg from '../utils/images/athletics-img.png'
import BadmintonImg from '../utils/images/badminton-img.png'
import BasketballImg from '../utils/images/basketball-img.png'
import BodyTransformationImg from '../utils/images/body-transformation-img.png'
import CricketImg from '../utils/images/cricket-img.png'
import FencingImg from '../utils/images/fencing-img.png'
import FootballImg from '../utils/images/football-img.png'
import GolfImg from '../utils/images/golf-img.png'
import HandballImg from '../utils/images/handball-img.png'
import HockeyImg from '../utils/images/hockey-img.png'
import IceHockeyImg from '../utils/images/ice-hockey-img.png'
import LacrosseImg from '../utils/images/lacrosse-img.png'
import MmaImg from '../utils/images/mma-img.png'
import NetballImg from '../utils/images/netball-img.png'
import RowingImg from '../utils/images/rowing-img.png'
import RugbyImg from '../utils/images/rugby-img.png'
import SkiingImg from '../utils/images/skiing-img.png'
import SquashImg from '../utils/images/squash-img.png'
import TennisImg from '../utils/images/tennis-img.png'
import VolleyballImg from '../utils/images/volleyball-img.png'

export const a = [
    {
        title: "Athletics",
        img: AthleticsImg
    },
    {
        title: "Badminton",
        img: BadmintonImg
    },
    {
        title: "Basketball",
        img: BasketballImg
    },
    {
        title: "Body Transformation",
        img: BodyTransformationImg
    },
    {
        title: "Cricket",
        img: CricketImg
    },
    {
        title: "Fencing",
        img: FencingImg
    },
    {
        title: "Football",
        img: FootballImg
    },
    {
        title: "Golf",
        img: GolfImg
    },
    {
        title: "Handball",
        img: HandballImg
    },
    {
        title: "Hockey",
        img: HockeyImg
    },
    {
        title: "Ice Hockey",
        img: HandballImg
    },
    {
        title: "Handball",
        img: IceHockeyImg
    },
    {
        title: "Lacrosse",
        img: LacrosseImg
    },
    {
        title: "MMA",
        img: MmaImg
    },
    {
        title: "Netball",
        img: NetballImg
    },
    {
        title: "Rowing",
        img: RowingImg
    },
    {
        title: "Rugby",
        img: RugbyImg
    },
    {
        title: "Skiing",
        img: SkiingImg
    },
    {
        title: "Squash",
        img: SquashImg
    },
    {
        title: "Tennis",
        img: TennisImg
    },
    {
        title: "Volleyball",
        img: VolleyballImg
    },
]
// import React from 'react'


// const AtheletSignup = () => {
//   return (
      
//       <div className="signup-wrapper">
//     <div className="container">
//         <div className="row">
//             <div className="col-lg-6 m-auto">
//                 <form className="prime_signup_form">
//                     <div className="heading text-center">
//                         SignUp for Athelets
//                     </div>
//                     <div className="form-group mb-4">
//                         <input type="text" className="form-control" id="name" aria-describedby="name" placeholder="Name"/>
//                     </div>

//                     <div className="form-group">
//                         <select name="" id="" className="form-control">
//                             <option value="">Free Trial</option>
//                             <option value="">Standard Membership</option>
//                             <option value="">Prime Membership</option>
//                         </select>
//                     </div>

//                     <div className="form-group mb-4">
//                         <input type="text" className="form-control" id="UserName" aria-describedby="Username" placeholder="Username"/>
//                     </div>

//                     <div className="form-group mb-4">
//                         <input type="email" className="form-control" id="InputEmail" aria-describedby="emailHelp" placeholder="Enter email"/>
//                     </div>
                    
//                     <div className="form-group mb-4">
//                         <input type="password" className="form-control" id="InputPassword1" placeholder="Password"/>
//                     </div>
//                     <div className="custom-control custom-checkbox pb-4">
//                         <input type="checkbox" className="custom-control-input" id="customCheck1"/>
//                         <label className="custom-control-label" for="customCheck1">Remember me?</label>
//                     </div>
//                     <button type="submit" className="btn btn-primary">Submit</button>
//                 </form>
//             </div>
//         </div>
//     </div>
// </div>

   
//   )
// }

// export default AtheletSignup
